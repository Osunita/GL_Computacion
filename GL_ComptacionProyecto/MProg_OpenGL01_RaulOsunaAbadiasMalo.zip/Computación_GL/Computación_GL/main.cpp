#include <iostream>
#include <glad/glad.h>
#include <GLFW/glfw3.h>


class Shader {
public:
    unsigned int ID;

    Shader(const char* source, GLenum shaderType) {
        ID = glCreateShader(shaderType);
        glShaderSource(ID, 1, &source, nullptr);
        glCompileShader(ID);
    }

    ~Shader() {
        glDeleteShader(ID);
    }
};

class ShaderProgram {
public:
    unsigned int ID;

    ShaderProgram(const Shader& vertexShader, const Shader& fragmentShader) {
        ID = glCreateProgram();
        glAttachShader(ID, vertexShader.ID); 
        glAttachShader(ID, fragmentShader.ID); 
        glLinkProgram(ID); 
        glUseProgram(ID); 
    }

    int getUniformLocation(const char* name) const {
        return glGetUniformLocation(ID, name);
    }

    ~ShaderProgram() {
        glDeleteProgram(ID);
    }
};

void framebuffer_size_callback(GLFWwindow* window, int width, int height) {
    glViewport(0, 0, width, height);
}

int main() {
    glfwInit();

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    GLFWwindow* window = glfwCreateWindow(800, 600, "Computacion Grafica", nullptr, nullptr);
    if (window == nullptr) {
        std::cout << "Failed to create the window" << std::endl;
        glfwTerminate();
        return -1;
    }

    glfwMakeContextCurrent(window);

    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }

    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

    // C�digo fuente de shaders
    const char* vertexShaderSource = "#version 330 core\n"
        "layout (location = 0) in vec3 aPos;\n"
        "void main()\n"
        "{\n"
        "   gl_Position = vec4(aPos.x, aPos.y, aPos.z, 1.0);\n"
        "}\0";

    const char* fragmentShaderSource = "#version 330 core\n"
        "out vec4 FragColor;\n"
        "uniform vec4 alternativeColor;\n"
        "void main()\n"
        "{\n"
        "   FragColor = alternativeColor;\n"
        "}\0";


    Shader vertexShader(vertexShaderSource, GL_VERTEX_SHADER);
    Shader fragmentShader(fragmentShaderSource, GL_FRAGMENT_SHADER);
    ShaderProgram shaderProgram(vertexShader, fragmentShader);

    float vertices[] = {
         0.f, 0.f, 0.f, //0
         -0.1f, 0.35f, 0.f, //1
         0.1f, 0.35f, 0.f, //2
         -0.1f, -0.05f, 0.f, //3
         -0.25f, 0.18f, 0.f, //4
         0.1f, -0.05f, 0.f, //5
         0.25f, 0.18f, 0.f, //6
         0.28f,  0.5f, 0.f, //7
         -0.28f,  0.5f, 0.f, //8
         -0.32f, -0.1, 0.f, //9
         0.32f, -0.1, 0.f, //10
         -0.05f, -0.35f, 0.f,//11
         0.05f, -0.35f, 0.f, //12
         0.f, -0.32f, 0.f, //13

         //detalles ojos
         -0.16f, -0.065, 0.f, //14
         -0.09f, -0.13f, 0.f, //15
         0.16f, -0.065, 0.f, //16
         0.09f, -0.13f, 0.f, //17
    };

    unsigned int indices[] = {
        0,1,2, //frente centro
        0,1,3, //frente izquierda
        3,1,4,
        0,2,5,  //frente derecha
        5,2,6,
        1,4,8, //oreja izquierda
        2,6,7, //oreja derecha
        4,3,9, //cabeza izquierda
        5,6,10, //cabeza derecha
        9,3,11, //mejilla izquierda
        5,10,12, //mejilla derecha
        0,3,11, //hocico izquierda
        0,11,13,
        0,5,12, //hocico derecha
        0,12,13,

        //Detalles
        11,12,13, //hocico
        3,14,15, //ojo izquierdo
        5,16,17, //ojo derecho
    };

    unsigned int VBO, VAO, IBO;

    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glGenBuffers(1, &IBO);

    glBindVertexArray(VAO);

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    glBindBuffer(GL_ARRAY_BUFFER, 0);

    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

    int alternativeColorLocation = shaderProgram.getUniformLocation("alternativeColor");

    while (!glfwWindowShouldClose(window)) {
        glClear(GL_COLOR_BUFFER_BIT);

        glBindVertexArray(VAO);

        glUniform4f(alternativeColorLocation, 1.0f, 1.0f, 1.0f, 1.0f);
        glDrawElements(GL_TRIANGLES, 45, GL_UNSIGNED_INT, 0);

        //Detalles hocico y ojos
        glUniform4f(alternativeColorLocation, 0.27f, 0.3f, 0.305f, 1.0f);
        glDrawElements(GL_TRIANGLES, 9, GL_UNSIGNED_INT, (int*)NULL + 45);

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);

    glfwTerminate();
    return 0;
}
