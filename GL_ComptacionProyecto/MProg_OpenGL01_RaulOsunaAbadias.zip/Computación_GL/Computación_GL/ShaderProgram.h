#pragma once
#include "Shader.h"

class ShaderProgram {
public:
    unsigned int ID;

    ShaderProgram(const Shader& vertexShader, const Shader& fragmentShader);

    void use() const;

    int getUniformLocation(const char* name) const;

    ~ShaderProgram();
};

