#include "ShaderProgram.h"

ShaderProgram::ShaderProgram(const Shader& vertexShader, const Shader& fragmentShader) {
    ID = glCreateProgram();
    glAttachShader(ID, vertexShader.ID);
    glAttachShader(ID, fragmentShader.ID);
    glLinkProgram(ID);
    glUseProgram(ID);
}

void ShaderProgram::use() const {
    glUseProgram(ID);
}

int ShaderProgram::getUniformLocation(const char* name) const {
    return glGetUniformLocation(ID, name);
}

ShaderProgram::~ShaderProgram() {
    glDeleteProgram(ID);
}
