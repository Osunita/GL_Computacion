#include "Shader.h"

Shader::Shader(const char* source, GLenum shaderType) {
    ID = glCreateShader(shaderType);
    glShaderSource(ID, 1, &source, nullptr);
    glCompileShader(ID);
}

Shader::~Shader() {
    glDeleteShader(ID);
}

